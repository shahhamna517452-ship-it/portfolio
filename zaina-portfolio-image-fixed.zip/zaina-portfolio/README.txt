Zaina Khan Lodhi — Premium Portfolio
=====================================

Open index.html in a browser to preview the portfolio.

Files:
- index.html
- style.css
- script.js
- assets/images/ (place Zaina's approved professional photo here)

The current design uses a dark charcoal + warm gold professional theme.
Replace the ZL placeholder with the real profile photo when available.
