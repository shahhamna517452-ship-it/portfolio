// ============ ELEMENTS ============
const navToggle = document.getElementById('navToggle');
const navLinks = document.getElementById('navLinks');
const progressBar = document.getElementById('progressBar');
const backToTop = document.getElementById('backToTop');
const navbar = document.getElementById('navbar');

// ============ MOBILE NAV ============
if (navToggle && navLinks) {
  navToggle.addEventListener('click', () => {
    navToggle.classList.toggle('open');
    navLinks.classList.toggle('mobile-open');
    navToggle.setAttribute(
      'aria-expanded',
      navLinks.classList.contains('mobile-open') ? 'true' : 'false'
    );
  });

  navLinks.querySelectorAll('a').forEach(link => {
    link.addEventListener('click', () => {
      navToggle.classList.remove('open');
      navLinks.classList.remove('mobile-open');
      navToggle.setAttribute('aria-expanded', 'false');
    });
  });
}

// ============ SCROLL PROGRESS + NAV ============
function updateScrollUI() {
  const scrollTop = window.scrollY;
  const docHeight = document.documentElement.scrollHeight - window.innerHeight;
  const progress = docHeight > 0 ? (scrollTop / docHeight) * 100 : 0;

  if (progressBar) progressBar.style.width = `${progress}%`;

  if (backToTop) {
    const show = scrollTop > 500;
    backToTop.classList.toggle('show', show);
  }

  if (navbar) {
    navbar.classList.toggle('scrolled', scrollTop > 30);
  }
}

window.addEventListener('scroll', updateScrollUI, { passive: true });

// ============ BACK TO TOP ============
if (backToTop) {
  backToTop.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  });
}

// ============ SCROLL REVEAL ============
const revealElements = document.querySelectorAll('.reveal');

if ('IntersectionObserver' in window) {
  const revealObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('active');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  revealElements.forEach(el => revealObserver.observe(el));
} else {
  revealElements.forEach(el => el.classList.add('active'));
}

// ============ ACTIVE NAV LINK ============
const sections = [...document.querySelectorAll('main section[id]')];
const navItems = [...document.querySelectorAll('.nav-links a')];

if ('IntersectionObserver' in window && sections.length && navItems.length) {
  const sectionObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;

      navItems.forEach(link => {
        link.classList.toggle(
          'active',
          link.getAttribute('href') === `#${entry.target.id}`
        );
      });
    });
  }, { rootMargin: '-35% 0px -55% 0px', threshold: 0 });

  sections.forEach(section => sectionObserver.observe(section));
}

// Initial UI state
updateScrollUI();
